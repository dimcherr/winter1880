Slimmary is a casual style handwritten font, light and elegant.

Slimmary is distributed under The SIL Open Font License (OFL) and is completely free for both personal and commercial use.

Designed by Dmitri Zdorov, the latest version is available from https://dimka.com/fonts/

Attribution is not required but welcome.

Tips and donations: https://www.buymeacoffee.com/Dimka