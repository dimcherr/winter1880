Wolgadeutsche font (basic Latin, Cyrillic, also added glyphs characteristic of the German language), distributed completely free of charge for personal and commercial use.

You can always support us with donations:
https://justreyb.gumroad.com/l/Wolgadeutsche

Appreciate and follow:
https://www.behance.net/gallery/190682841/Wolgadeutsche-Free-Font